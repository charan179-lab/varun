import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { CourseList } from './components/courses/CourseList';
import { CodeEditor } from './components/coding/CodeEditor';
import { ProgressTracker } from './components/progress/ProgressTracker';
import { AssessmentSystem } from './components/assessment/AssessmentSystem';
import { GroupCodingRoom } from './components/group/GroupCodingRoom';
import { AnalyticsDashboard } from './components/faculty/AnalyticsDashboard';

function App() {
  // Temporary user role state - this would normally come from authentication
  const [userRole] = useState<'student' | 'faculty' | 'admin'>('student');

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation role={userRole} />
        <main className="ml-64 min-h-screen">
          <header className="bg-white shadow">
            <div className="px-6 py-4">
              <h1 className="text-xl font-semibold text-gray-800">Welcome to Campus Bridge</h1>
            </div>
          </header>
          
          <Routes>
            <Route path="/" element={<Dashboard role={userRole} />} />
            <Route path="/courses" element={<CourseList />} />
            <Route path="/coding" element={<CodeEditor />} />
            <Route path="/progress" element={<ProgressTracker />} />
            <Route path="/assessment" element={<AssessmentSystem />} />
            <Route path="/group-coding" element={<GroupCodingRoom />} />
            <Route path="/analytics" element={<AnalyticsDashboard />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;