import React from 'react';
import { BookOpen, Code, Trophy, Users } from 'lucide-react';

interface DashboardProps {
  role: 'student' | 'faculty' | 'admin';
}

export const Dashboard: React.FC<DashboardProps> = ({ role }) => {
  const stats = {
    student: [
      { icon: <BookOpen size={24} />, label: 'Enrolled Courses', value: '5' },
      { icon: <Code size={24} />, label: 'Coding Problems Solved', value: '127' },
      { icon: <Trophy size={24} />, label: 'Current Streak', value: '7 days' },
      { icon: <Users size={24} />, label: 'Group Sessions', value: '3' },
    ],
    faculty: [
      { icon: <BookOpen size={24} />, label: 'Active Courses', value: '3' },
      { icon: <Users size={24} />, label: 'Total Students', value: '150' },
      { icon: <Code size={24} />, label: 'Assignments', value: '12' },
      { icon: <Trophy size={24} />, label: 'Average Score', value: '85%' },
    ],
    admin: [
      { icon: <Users size={24} />, label: 'Total Users', value: '1,250' },
      { icon: <BookOpen size={24} />, label: 'Active Courses', value: '25' },
      { icon: <Code size={24} />, label: 'Coding Submissions', value: '5,127' },
      { icon: <Trophy size={24} />, label: 'Placement Rate', value: '92%' },
    ],
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats[role].map((stat, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow p-6 flex items-center gap-4"
          >
            <div className="p-3 bg-indigo-100 rounded-full text-indigo-600">
              {stat.icon}
            </div>
            <div>
              <p className="text-sm text-gray-600">{stat.label}</p>
              <p className="text-xl font-semibold">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};