import React from 'react';
import { Link } from 'react-router-dom';
import {
  Menu,
  BookOpen,
  Code,
  Users,
  BarChart,
  LogOut,
  ClipboardCheck,
  UsersRound,
  Trophy
} from 'lucide-react';

interface NavProps {
  role: 'student' | 'faculty' | 'admin';
}

export const Navigation: React.FC<NavProps> = ({ role }) => {
  const navItems = {
    student: [
      { icon: <BookOpen size={20} />, label: 'Courses', path: '/courses' },
      { icon: <Code size={20} />, label: 'Coding Arena', path: '/coding' },
      { icon: <Trophy size={20} />, label: 'Progress', path: '/progress' },
      { icon: <ClipboardCheck size={20} />, label: 'Assessments', path: '/assessment' },
      { icon: <UsersRound size={20} />, label: 'Group Coding', path: '/group-coding' },
    ],
    faculty: [
      { icon: <BookOpen size={20} />, label: 'My Courses', path: '/courses' },
      { icon: <Users size={20} />, label: 'Students', path: '/students' },
      { icon: <BarChart size={20} />, label: 'Analytics', path: '/analytics' },
      { icon: <ClipboardCheck size={20} />, label: 'Assessments', path: '/assessment' },
    ],
    admin: [
      { icon: <Users size={20} />, label: 'Users', path: '/users' },
      { icon: <BookOpen size={20} />, label: 'Courses', path: '/courses' },
      { icon: <BarChart size={20} />, label: 'Reports', path: '/reports' },
    ],
  };

  return (
    <nav className="bg-indigo-700 text-white h-screen w-64 fixed left-0 top-0 p-4">
      <div className="flex items-center gap-3 mb-8">
        <Menu size={24} />
        <h1 className="text-xl font-bold">Campus Bridge</h1>
      </div>
      
      <div className="space-y-2">
        {navItems[role].map((item, index) => (
          <Link
            key={index}
            to={item.path}
            className="flex items-center gap-3 p-3 rounded hover:bg-indigo-600 transition-colors"
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}
      </div>

      <div className="absolute bottom-4 w-full left-0 px-4">
        <button className="flex items-center gap-3 p-3 rounded hover:bg-indigo-600 transition-colors w-full">
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </nav>
  );
};