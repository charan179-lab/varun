import React, { useState } from 'react';
import { Send, Bot, Loader } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "I've analyzed your code. Here are some suggestions:\n\n" +
                "1. Consider using a hash map to optimize the time complexity\n" +
                "2. Add input validation for edge cases\n" +
                "3. The variable naming could be more descriptive\n\n" +
                "```javascript\n" +
                "function twoSum(nums, target) {\n" +
                "  const map = new Map();\n" +
                "  for (let i = 0; i < nums.length; i++) {\n" +
                "    const complement = target - nums[i];\n" +
                "    if (map.has(complement)) {\n" +
                "      return [map.get(complement), i];\n" +
                "    }\n" +
                "    map.set(nums[i], i);\n" +
                "  }\n" +
                "  return [];\n" +
                "}\n" +
                "```",
        role: 'assistant',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      <div className="flex items-center gap-2 p-4 border-b border-gray-700">
        <Bot size={24} className="text-indigo-400" />
        <h2 className="text-lg font-semibold">AI Assistant</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.role === 'user'
                  ? 'bg-indigo-600'
                  : 'bg-gray-700'
              }`}
            >
              <ReactMarkdown
                className="prose prose-invert"
                components={{
                  code: ({ node, inline, className, children, ...props }) => (
                    <code
                      className={`${className} ${
                        inline ? 'bg-gray-800 rounded px-1' : 'block bg-gray-800 p-2 rounded'
                      }`}
                      {...props}
                    >
                      {children}
                    </code>
                  ),
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-700 rounded-lg p-3">
              <Loader className="animate-spin" size={20} />
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-gray-700">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask for help with your code..."
            className="flex-1 bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleSend}
            disabled={isLoading}
            className="bg-indigo-600 hover:bg-indigo-700 rounded-lg px-4 py-2 flex items-center gap-2"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};