import React, { useState } from 'react';
import { CheckCircle2, XCircle, Clock, AlertCircle } from 'lucide-react';

interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

interface Assessment {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  questions: Question[];
}

const sampleAssessment: Assessment = {
  id: '1',
  title: 'Data Structures Fundamentals',
  description: 'Test your knowledge of basic data structures concepts',
  timeLimit: 30,
  questions: [
    {
      id: '1',
      text: 'What is the time complexity of searching in a balanced binary search tree?',
      options: ['O(1)', 'O(log n)', 'O(n)', 'O(n²)'],
      correctAnswer: 1
    },
    {
      id: '2',
      text: 'Which data structure follows the LIFO principle?',
      options: ['Queue', 'Stack', 'Linked List', 'Array'],
      correctAnswer: 1
    }
  ]
};

export const AssessmentSystem: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(sampleAssessment.timeLimit * 60);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const calculateScore = () => {
    let correct = 0;
    answers.forEach((answer, index) => {
      if (answer === sampleAssessment.questions[index].correctAnswer) {
        correct++;
      }
    });
    return (correct / sampleAssessment.questions.length) * 100;
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold">{sampleAssessment.title}</h2>
            <p className="text-gray-600">{sampleAssessment.description}</p>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Clock size={20} />
            <span>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>

        {!isSubmitted ? (
          <div>
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm text-gray-600">Question {currentQuestion + 1} of {sampleAssessment.questions.length}</span>
                <div className="flex-1 h-2 bg-gray-200 rounded-full">
                  <div
                    className="h-2 bg-indigo-600 rounded-full"
                    style={{ width: `${((currentQuestion + 1) / sampleAssessment.questions.length) * 100}%` }}
                  />
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-4">{sampleAssessment.questions[currentQuestion].text}</h3>
              <div className="space-y-3">
                {sampleAssessment.questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    className={`w-full text-left p-4 rounded-lg border ${
                      answers[currentQuestion] === index
                        ? 'border-indigo-600 bg-indigo-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-between">
              <button
                onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
                disabled={currentQuestion === 0}
                className="px-4 py-2 text-indigo-600 disabled:text-gray-400"
              >
                Previous
              </button>
              {currentQuestion === sampleAssessment.questions.length - 1 ? (
                <button
                  onClick={() => setIsSubmitted(true)}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Submit
                </button>
              ) : (
                <button
                  onClick={() => setCurrentQuestion(prev => Math.min(sampleAssessment.questions.length - 1, prev + 1))}
                  className="px-4 py-2 text-indigo-600"
                >
                  Next
                </button>
              )}
            </div>
          </div>
        ) : (
          <div>
            <div className="text-center mb-8">
              <div className="inline-block p-4 bg-indigo-100 rounded-full text-indigo-600 mb-4">
                <Trophy size={48} />
              </div>
              <h3 className="text-2xl font-bold mb-2">Assessment Complete!</h3>
              <p className="text-gray-600">You scored {calculateScore()}%</p>
            </div>

            <div className="space-y-4">
              {sampleAssessment.questions.map((question, index) => (
                <div key={question.id} className="border rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    {answers[index] === question.correctAnswer ? (
                      <CheckCircle2 className="text-green-500 mt-1" size={20} />
                    ) : (
                      <XCircle className="text-red-500 mt-1" size={20} />
                    )}
                    <div>
                      <h4 className="font-semibold mb-2">{question.text}</h4>
                      <div className="space-y-2">
                        {question.options.map((option, optIndex) => (
                          <div
                            key={optIndex}
                            className={`p-2 rounded ${
                              optIndex === question.correctAnswer
                                ? 'bg-green-100'
                                : optIndex === answers[index]
                                ? 'bg-red-100'
                                : 'bg-gray-50'
                            }`}
                          >
                            {option}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};