import React, { useState } from 'react';
import Editor from '@monaco-editor/react';
import { Play, RotateCcw, MessageSquareMore, X } from 'lucide-react';
import { AIAssistant } from '../ai/AIAssistant';

const defaultCode = `function solution(input) {
  // Write your code here
  
  return output;
}`;

export const CodeEditor: React.FC = () => {
  const [code, setCode] = useState(defaultCode);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [showAI, setShowAI] = useState(false);

  const handleRunCode = () => {
    setIsRunning(true);
    // Simulate code execution
    setTimeout(() => {
      setOutput('Output will appear here...');
      setIsRunning(false);
    }, 1000);
  };

  return (
    <div className="h-screen flex">
      <div className="flex-1 flex flex-col">
        <div className="bg-gray-800 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <select className="bg-gray-700 rounded px-3 py-1">
              <option>Python</option>
              <option>JavaScript</option>
              <option>Java</option>
              <option>C++</option>
            </select>
            <button
              onClick={handleRunCode}
              disabled={isRunning}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 px-4 py-1 rounded"
            >
              <Play size={16} />
              Run
            </button>
            <button className="flex items-center gap-2 hover:bg-gray-700 px-4 py-1 rounded">
              <RotateCcw size={16} />
              Reset
            </button>
          </div>
          <button
            onClick={() => setShowAI(!showAI)}
            className={`flex items-center gap-2 px-4 py-1 rounded ${
              showAI ? 'bg-indigo-600' : 'hover:bg-gray-700'
            }`}
          >
            <MessageSquareMore size={16} />
            AI Assistant
          </button>
        </div>
        
        <div className="flex-1">
          <Editor
            height="100%"
            defaultLanguage="javascript"
            theme="vs-dark"
            value={code}
            onChange={(value) => setCode(value || '')}
            options={{
              minimap: { enabled: false },
              fontSize: 14,
              lineNumbers: 'on',
              automaticLayout: true,
            }}
          />
        </div>
      </div>
      
      <div className="w-1/3 bg-gray-900 text-white">
        {showAI ? (
          <AIAssistant />
        ) : (
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-4">Problem: Two Sum</h3>
            <div className="prose prose-invert">
              <p>Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.</p>
              <h4>Example:</h4>
              <pre className="bg-gray-800 p-3 rounded">
                Input: nums = [2,7,11,15], target = 9
                Output: [0,1]
              </pre>
            </div>
            
            <div className="mt-6">
              <h4 className="font-semibold mb-2">Output:</h4>
              <pre className="bg-gray-800 p-3 rounded min-h-[100px]">
                {output}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};