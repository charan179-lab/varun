import React from 'react';
import { BookOpen, Clock, Users, Star } from 'lucide-react';

interface Course {
  id: string;
  title: string;
  instructor: string;
  enrolled: number;
  duration: string;
  rating: number;
  image: string;
}

const courses: Course[] = [
  {
    id: '1',
    title: 'Data Structures & Algorithms',
    instructor: 'Dr. Sarah Chen',
    enrolled: 156,
    duration: '12 weeks',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?auto=format&fit=crop&w=400&h=250'
  },
  {
    id: '2',
    title: 'Advanced Web Development',
    instructor: 'Prof. Michael Rodriguez',
    enrolled: 124,
    duration: '10 weeks',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=400&h=250'
  },
  {
    id: '3',
    title: 'Machine Learning Fundamentals',
    instructor: 'Dr. Emily Watson',
    enrolled: 198,
    duration: '14 weeks',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=400&h=250'
  }
];

export const CourseList: React.FC = () => {
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Available Courses</h2>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors">
          Create Course
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <div key={course.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <img src={course.image} alt={course.title} className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
              <p className="text-gray-600 mb-4">{course.instructor}</p>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Users size={18} className="text-gray-500" />
                  <span className="text-sm text-gray-600">{course.enrolled} students</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={18} className="text-gray-500" />
                  <span className="text-sm text-gray-600">{course.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star size={18} className="text-yellow-500" />
                  <span className="text-sm text-gray-600">{course.rating}/5.0</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen size={18} className="text-gray-500" />
                  <span className="text-sm text-gray-600">24 lessons</span>
                </div>
              </div>
              
              <button className="w-full bg-indigo-50 text-indigo-600 py-2 rounded-lg hover:bg-indigo-100 transition-colors">
                View Course
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};