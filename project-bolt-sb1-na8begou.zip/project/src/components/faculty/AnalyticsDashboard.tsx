import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Users, BookOpen, Award, Brain } from 'lucide-react';

const performanceData = [
  { course: 'Data Structures', avgScore: 85, submissions: 150, completion: 78 },
  { course: 'Algorithms', avgScore: 76, submissions: 130, completion: 65 },
  { course: 'Web Development', avgScore: 92, submissions: 180, completion: 88 },
  { course: 'Database Systems', avgScore: 81, submissions: 140, completion: 72 },
];

const weeklyActivity = [
  { week: 'Week 1', students: 120, submissions: 350 },
  { week: 'Week 2', students: 150, submissions: 420 },
  { week: 'Week 3', students: 140, submissions: 380 },
  { week: 'Week 4', students: 180, submissions: 450 },
];

const skillDistribution = [
  { name: 'Excellent', value: 30 },
  { name: 'Good', value: 45 },
  { name: 'Average', value: 20 },
  { name: 'Needs Improvement', value: 5 },
];

const COLORS = ['#4ade80', '#6366f1', '#f59e0b', '#ef4444'];

export const AnalyticsDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 rounded-full text-indigo-600">
              <Users size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Students</p>
              <p className="text-2xl font-bold">256</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-100 rounded-full text-green-600">
              <BookOpen size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Active Courses</p>
              <p className="text-2xl font-bold">12</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-yellow-100 rounded-full text-yellow-600">
              <Award size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Avg. Score</p>
              <p className="text-2xl font-bold">85%</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-100 rounded-full text-purple-600">
              <Brain size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Completion Rate</p>
              <p className="text-2xl font-bold">78%</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Course Performance</h3>
          <BarChart width={500} height={300} data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="course" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="avgScore" fill="#6366f1" name="Average Score" />
            <Bar dataKey="completion" fill="#4ade80" name="Completion Rate" />
          </BarChart>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Weekly Activity</h3>
          <LineChart width={500} height={300} data={weeklyActivity}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="week" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="students" stroke="#6366f1" name="Active Students" />
            <Line type="monotone" dataKey="submissions" stroke="#4ade80" name="Submissions" />
          </LineChart>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Student Performance Distribution</h3>
          <PieChart width={300} height={300}>
            <Pie
              data={skillDistribution}
              cx={150}
              cy={150}
              innerRadius={60}
              outerRadius={100}
              fill="#8884d8"
              paddingAngle={5}
              dataKey="value"
            >
              {skillDistribution.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </div>

        <div className="col-span-2 bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Submissions</h3>
          <div className="space-y-4">
            {performanceData.map((course, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold">{course.course}</h4>
                  <p className="text-sm text-gray-600">{course.submissions} submissions</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-semibold">{course.avgScore}%</p>
                    <p className="text-sm text-gray-600">Avg. Score</p>
                  </div>
                  <div className="h-10 w-10 flex items-center justify-center rounded-full bg-green-100 text-green-600">
                    <Award size={20} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};