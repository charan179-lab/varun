import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { Users, MessageSquare, Send, UserPlus } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface Message {
  id: string;
  user: string;
  content: string;
  timestamp: Date;
}

interface Participant {
  id: string;
  name: string;
  avatar: string;
}

export const GroupCodingRoom: React.FC = () => {
  const [code, setCode] = useState('// Start coding here...');
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [participants] = useState<Participant[]>([
    { id: '1', name: 'John Doe', avatar: 'https://ui-avatars.com/api/?name=John+Doe' },
    { id: '2', name: 'Jane Smith', avatar: 'https://ui-avatars.com/api/?name=Jane+Smith' },
    { id: '3', name: 'Mike Johnson', avatar: 'https://ui-avatars.com/api/?name=Mike+Johnson' },
  ]);

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const message: Message = {
      id: uuidv4(),
      user: 'You',
      content: newMessage,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
  };

  return (
    <div className="h-screen flex">
      <div className="w-64 bg-gray-800 text-white p-4 flex flex-col">
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Users size={20} />
            Participants
          </h2>
          <div className="space-y-3">
            {participants.map(participant => (
              <div key={participant.id} className="flex items-center gap-3">
                <img
                  src={participant.avatar}
                  alt={participant.name}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm">{participant.name}</span>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full flex items-center justify-center gap-2 py-2 rounded bg-indigo-600 hover:bg-indigo-700">
            <UserPlus size={16} />
            Invite
          </button>
        </div>

        <div className="flex-1 flex flex-col">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <MessageSquare size={20} />
            Chat
          </h2>
          <div className="flex-1 overflow-y-auto space-y-4 mb-4">
            {messages.map(message => (
              <div key={message.id} className="bg-gray-700 rounded-lg p-3">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-semibold">{message.user}</span>
                  <span className="text-xs text-gray-400">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm">{message.content}</p>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 bg-gray-700 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={sendMessage}
              className="p-2 rounded bg-indigo-600 hover:bg-indigo-700"
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="bg-gray-900 text-white p-4">
          <h1 className="text-lg font-semibold">Group Coding Session</h1>
          <p className="text-sm text-gray-400">Problem: Implement a Binary Search Tree</p>
        </div>
        <Editor
          height="calc(100vh - 64px)"
          defaultLanguage="javascript"
          theme="vs-dark"
          value={code}
          onChange={(value) => setCode(value || '')}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            lineNumbers: 'on',
            automaticLayout: true,
          }}
        />
      </div>
    </div>
  );
};