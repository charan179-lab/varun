import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Award, Target, Clock } from 'lucide-react';

const progressData = [
  { week: 'Week 1', problems: 12, hours: 8 },
  { week: 'Week 2', problems: 15, hours: 10 },
  { week: 'Week 3', problems: 8, hours: 6 },
  { week: 'Week 4', problems: 20, hours: 12 },
];

const skillData = [
  { name: 'DSA', value: 75 },
  { name: 'Web Dev', value: 85 },
  { name: 'Python', value: 60 },
  { name: 'Java', value: 45 },
];

const COLORS = ['#6366f1', '#8b5cf6', '#d946ef', '#f43f5e'];

export const ProgressTracker: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-indigo-100 rounded-full text-indigo-600">
              <Award size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Problems Solved</h3>
              <p className="text-3xl font-bold">55</p>
            </div>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div className="h-2 bg-indigo-600 rounded-full" style={{ width: '70%' }} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-purple-100 rounded-full text-purple-600">
              <Target size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Current Streak</h3>
              <p className="text-3xl font-bold">7 days</p>
            </div>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div className="h-2 bg-purple-600 rounded-full" style={{ width: '85%' }} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-pink-100 rounded-full text-pink-600">
              <Clock size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Practice Hours</h3>
              <p className="text-3xl font-bold">36</p>
            </div>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div className="h-2 bg-pink-600 rounded-full" style={{ width: '60%' }} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Weekly Progress</h3>
          <LineChart width={500} height={300} data={progressData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="week" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="problems" stroke="#6366f1" />
            <Line type="monotone" dataKey="hours" stroke="#8b5cf6" />
          </LineChart>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Skill Distribution</h3>
          <PieChart width={400} height={300}>
            <Pie
              data={skillData}
              cx={200}
              cy={150}
              innerRadius={60}
              outerRadius={100}
              fill="#8884d8"
              paddingAngle={5}
              dataKey="value"
            >
              {skillData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </div>
      </div>
    </div>
  );
};