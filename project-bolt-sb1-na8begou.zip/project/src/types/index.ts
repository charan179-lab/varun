export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'faculty' | 'admin';
  department?: string;
  semester?: number;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  materials: CourseMaterial[];
}

export interface CourseMaterial {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'quiz';
  url: string;
  uploadedAt: Date;
}

export interface CodingProblem {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
  testCases: TestCase[];
}

export interface TestCase {
  input: string;
  expectedOutput: string;
}

export interface UserProgress {
  userId: string;
  courseId: string;
  completedLessons: string[];
  codingScore: number;
  attendance: number;
}